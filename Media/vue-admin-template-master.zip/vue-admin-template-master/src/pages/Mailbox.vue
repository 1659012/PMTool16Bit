<template>
  <div style="height: 1400px;">
    Mailbox
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>
